setwd("C:/Users//IT24101859//Desktop//IT24101859Lab04")

data <- read.table("Data 4.txt",header = TRUE,sep=" ")
fix(data)
attach(data)

##Part2

boxplot(X1,main="Box plot for Team Attendence",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X2,main="Box plot for Team Salary",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X3,main="Box plot for Team Years",outline=TRUE,outpch=8,horizontal=TRUE)

hist(X1,ylab="Frequency",Xlab="Team Attendence",main="Histogram for Team Attendence")
hist(X1,ylab="Frequency",Xlab="Team Attendence",main="Histogram for Team Salary")
hist(X1,ylab="Frequency",Xlab="Team Attendence",main="Histogram for Team for Years")

stem(X1)
stem(X2)
stem(X3)

##Part B

mean (X1)
mean (X2)
mean (X3)

median (X1)
median (X2)
median (X3)


sd(X1)
sd(X2)
sd(X3)

##Part C

summary(X1)
summary(X2)
summary(X3)

quantile(X1)
quantile(X2)
quantile(X3)
