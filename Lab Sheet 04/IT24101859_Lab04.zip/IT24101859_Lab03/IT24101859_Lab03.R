setwd("C:/Users/gayan/OneDrive/Desktop/IT24101859_Lab03")

##Question 01
branch_data <- read.table("Exercise.txt",header = TRUE,sep = ",")


#Question 02
str(branch_data)
